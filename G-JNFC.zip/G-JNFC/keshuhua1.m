clear();
clc();

%%%%%%%%%%%%�����Ĳ���%%%%%%%%%%%%%%%%
model='GFLCF';
%loadfilename=strcat('../result/',model,'/gauss/result.mat');
fontsize=14;
Vcolor=['b*','c*','m*','g*','r*'];%ÿ���������ɫ
%%%%%%%%%%%END%%%%%%%%%%%%%%%%%%%%%%%
load('result.mat');
[~,label]=max(V,[],2);
label=bestMap(gnd,label);
% ����ͼ�β����ñ���ɫΪ��ɫ
figure('Color', 'white'); % ����ͼ�δ��ڱ���Ϊ��ɫ
for i=1:size(fea,1)
    if label(i)==1
        plot(fea(i,1),fea(i,2),'b*');
        hold on;
    elseif label(i)==2
        plot(fea(i,1),fea(i,2),'c*');
        hold on;
    elseif label(i)==3
        plot(fea(i,1),fea(i,2),'m*');
        hold on;  
    elseif label(i)==4
        plot(fea(i,1),fea(i,2),'g*');
        hold on;  
    else
        plot(fea(i,1),fea(i,2),'r*');
        hold on;  
    end
end

for index=1:length(fuzzypoint)
   i=fuzzypoint(index); 
   plot(fea(i,1),fea(i,2),'ko');
   text(fea(i,1)+0.05, fea(i,2)-0.01, num2str(i),'fontsize',16);
end

set(gca,'fontsize',14);
print -depsc fea_f.eps
print  -dtiff -r500 fea_f.tiff
