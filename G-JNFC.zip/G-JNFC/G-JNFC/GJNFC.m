function [final_U,final_V,final_history_obj] = GJNFC(X,c,lambda,gamma,options)
%X: d*n, must be nonnegtative
%c: number of cluster
%lamda,gamma: parameter
%optins: 
%   maxiter: max times of each iterative
%   trynum: different initialization of U,V, try times of main iterative
%   mu,beta: ALM parameter;
if min(min(X))<0
    error('matrix entries can not be negative');
    return;
end
if min(sum(X,2)) == 0
    zeroidx = find(sum(X,2) == 0);
    X(zeroidx, :) = [];
    fprintf('not all entries in a row can be zero');
end

[d,n]=size(X);
maxiter=options.maxiter;
trynum=options.trynum;
mu=options.mu;
beta=options.beta;
%calculate graph Laplacian matrix L
options1=[];
options1.NeighborMode = 'KNN';
options1.k = 5;
options1.WeightMode = 'HeatKernel';
options1.t = 1;
W = constructW(X',options1);
W=full(W);
D=diag(sum(W,2));
L=D-W;
%end calculate L
for tn=1:trynum
   %Initialize random U,V
   U=rand(d,c);
   V=rand(n,c);
   E=zeros(n,c);
   history_obj=[];
   %main iteration
    for i=1:maxiter
       %update U
       H=diag(sum(V)); %c*c
       U=U.*(((lambda+1)*X*V)./(U*(V'*V)+lambda*U*H+1e-9));
       %update V
       for a=1:n
           for k=1:c
                tmp=X(:,a)-U(:,k);
                E(a,k)=0.5*norm(tmp)^2;
           end
       end
       clear a;
       clear k;
       clear tmp;
       tmp=U'*X-lambda*E';
       for a=1:n
           A=U'*U+gamma*D(a,a)*eye(c);
           b=[];
           gsum=zeros(1,c);
           for g=1:n
               gsum=gsum+W(a,g)*V(g,:);
           end
           b=2*(tmp(:,a)+gamma*gsum');
           x=SimplexQP_ALM(A,b,mu,beta,0);
           V(a,:)=x;
       end
       %calculate obj
       obj=CalculateObj(X,U,V,lambda,L,gamma);
       history_obj=[history_obj;obj];
    end
    %judge optimun solution
    if tn==1
        final_history_obj=history_obj;
        final_U=U;
        final_V=V;
        final_obj=obj;
    else
        if obj< final_obj
            final_history_obj=history_obj;
            final_U=U;
            final_V=V;
            final_obj=obj;
        end  
    end
end
end

