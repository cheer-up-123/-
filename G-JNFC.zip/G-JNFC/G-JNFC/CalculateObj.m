function [obj] = CalculateObj(X,U,V,lambda,L,gamma)
    sum1=norm((X-U*V'),'fro')^2;
    [~,n]=size(X);
    [~,c]=size(U);
    sum2=0;
    for i=1:n
        for k=1:c
            tmp1=V(i,k)*norm(X(:,i)-U(:,k))^2;
            sum2=sum2+tmp1;
        end
    end
    sum3=gamma*trace(V'*L*V);
    obj=sum1+lambda*sum2+sum3;
end

 