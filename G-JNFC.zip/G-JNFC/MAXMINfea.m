function [fea] = MAXMINfea(X)
MAX=max(max(X));
MIN=min(min(X));
fea=(X-MIN)./(MAX-MIN);
end

